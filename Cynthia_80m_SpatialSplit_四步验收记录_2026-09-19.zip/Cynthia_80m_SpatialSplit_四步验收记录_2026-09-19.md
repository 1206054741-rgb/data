# Cynthia 80 m Spatial Split 四步验收记录

-   日期：2026-09-19
-   数据总量：813 对 RGB--配准温度图
-   当前候选划分：Train 613 / Validation 31 / Test 35 / Excluded 134
-   Active（Train+Val+Test）：679
-   当前
    Manifest：`/root/autodl-fs/data/cynthia_train_ready/manifest/spatial_80m_candidate/cynthia_spatial_80m_candidate_manifest.csv`
-   训练实际读取列：`split`
-   历史列：`legacy_split`（不参与训练）
-   本记录目的：汇总 80 m 空间划分的四项服务器验收结果及关键原始数值。

------------------------------------------------------------------------

## 0. 当前结果总览

  验收项目                                          结果
  ------------------------------------------------- ------------
  1\. 空间边界 / 跨 split 图像重叠筛查              **PASS**
  2\. Manifest / 文件读取 / DataLoader / 训练链路   **PASS**
  3\. Val/Test 温度与 RGB 代表性                    **REVIEW**
  4\. 6 张差异 Test 图客观质量检查                  **PASS**

> 注意：第 4 项 PASS 说明第 3 项中 Test 与 Train
> 的差异**不能简单归因于坏图、严重模糊、曝光异常、无效温度或无效
> Mask**。\
> 它并不会自动把第 3 项的 `REPRESENTATIVENESS CHECK = REVIEW` 改写成
> PASS。当前证据更支持：Test
> 中存在真实的场景/分布差异，需要在最终冻结划分时作为实验设计问题解释，而不是重新处理原始
> 813 对数据。

------------------------------------------------------------------------

# 1. 空间边界 / 图像重叠检查

## 1.1 Manifest 基本状态

-   Total：813
-   Train：613
-   Validation：31
-   Test：35
-   Excluded：134
-   训练读取列：`split`
-   `legacy_split used for training`：NO
-   `spatial_split` 歧义：NO
-   Manifest integrity：**PASS**

## 1.2 自动筛查参数

-   GPS candidate radius：≤ 130.0 m
-   SIFT maximum features：5000
-   Lowe ratio threshold：0.70
-   RANSAC reprojection threshold：4.0 px

### CLEAR_OVERLAP 判据（全部满足）

-   RANSAC inliers ≥ 35
-   Inlier ratio ≥ 0.35
-   Train feature coverage ≥ 3.00%
-   Val/Test feature coverage ≥ 3.00%

### REVIEW 判据

-   RANSAC inliers ≥ 18
-   Inlier ratio ≥ 0.22
-   但未满足全部 CLEAR_OVERLAP 条件

## 1.3 GPS 边界

### Train ↔ Validation

-   最近相机距离：**85.498 m**
-   最近 Pair：`004_00008` ↔ `004_00445`
-   ≤130 m 候选 Pair：**281**

### Train ↔ Test

-   最近相机距离：**85.415 m**
-   最近 Pair：`006_00037` ↔ `006_00063`
-   ≤130 m 候选 Pair：**331**

### 总计

-   实际自动检查候选 Pair：**612**

## 1.4 图像级几何匹配结果

### Train ↔ Validation

-   Candidate pairs：281
-   CLEAR_OVERLAP：**0**
-   REVIEW：**0**
-   NO_CLEAR_OVERLAP：281
-   Maximum good matches：14
-   Maximum RANSAC inliers：**6**
-   P95 inliers：4.00
-   P99 inliers：5.00
-   Maximum inlier ratio：0.6667
-   Maximum Train coverage：32.6967%
-   Maximum Val coverage：37.6010%

### Train ↔ Test

-   Candidate pairs：331
-   CLEAR_OVERLAP：**0**
-   REVIEW：**0**
-   NO_CLEAR_OVERLAP：331
-   Maximum good matches：15
-   Maximum RANSAC inliers：**6**
-   P95 inliers：5.00
-   P99 inliers：5.00
-   Maximum inlier ratio：0.6250
-   Maximum Train coverage：43.3316%
-   Maximum Test coverage：46.9833%

### 总结果

-   Total analysed：612
-   CLEAR_OVERLAP：**0**
-   REVIEW：**0**
-   NO_CLEAR_OVERLAP：**612**

## 1.5 Top 10 可疑 Pair

  ----------------------------------------------------------------------------------------------------
      Rank Pair        Split             GPS     Good   Inliers    Ratio   Coverage Decision
  -------- ----------- ------------ -------- -------- --------- -------- ---------- ------------------
         1 004_00505 ↔ train_val    116.71 m        9         6    0.667  17.356% / NO_CLEAR_OVERLAP
           004_00445                                                        17.973% 

         2 005_00050 ↔ train_test   128.65 m       11         6    0.545  14.042% / NO_CLEAR_OVERLAP
           005_00038                                                         0.415% 

         3 006_00073 ↔ train_test   121.65 m       11         6    0.545   6.472% / NO_CLEAR_OVERLAP
           005_00113                                                        25.576% 

         4 006_00072 ↔ train_test    97.81 m       15         6    0.400   9.421% / NO_CLEAR_OVERLAP
           006_00063                                                         3.265% 

         5 004_00044 ↔ train_val    125.41 m        8         5    0.625  32.697% / NO_CLEAR_OVERLAP
           004_00386                                                         3.132% 

         6 004_00389 ↔ train_val    128.56 m        8         5    0.625  32.434% / NO_CLEAR_OVERLAP
           004_00445                                                        20.107% 

         7 006_00071 ↔ train_test   108.37 m        8         5    0.625  30.711% / NO_CLEAR_OVERLAP
           006_00061                                                        32.729% 

         8 006_00073 ↔ train_test   109.66 m        8         5    0.625  27.243% / NO_CLEAR_OVERLAP
           006_00063                                                        24.933% 

         9 006_00037 ↔ train_test   101.15 m        8         5    0.625  21.654% / NO_CLEAR_OVERLAP
           005_00114                                                         5.164% 

        10 004_00416 ↔ train_test   110.92 m        8         5    0.625  21.471% / NO_CLEAR_OVERLAP
           005_00036                                                        20.211% 
  ----------------------------------------------------------------------------------------------------

### 验收 1 结论

**AUTOMATIC IMAGE-OVERLAP SCREEN = PASS**

612 个近边界跨 split Pair 中，没有任何 Pair 达到 REVIEW 或 CLEAR_OVERLAP
判据。最大 RANSAC inliers 仅为 6，低于 REVIEW 的 18 和 CLEAR_OVERLAP 的
35。

------------------------------------------------------------------------

# 2. Manifest / 文件读取 / DataLoader / 训练链路

## 2.1 Manifest / Split Safety

-   Rows：813
-   Training split column：`split`
-   `legacy_split used`：NO
-   `legacy_split` 与 `split` 不同的行数：**344**
-   Train：613
-   Validation：31
-   Test：35
-   Excluded：134
-   Active：679
-   Total：813
-   Manifest / split safety：**PASS**

## 2.2 Split Isolation / Excluded Protection

-   train ∩ val：0
-   train ∩ test：0
-   val ∩ test：0
-   train ∩ excluded：0
-   val ∩ excluded：0
-   test ∩ excluded：0
-   Excluded entering active data：**0**
-   Excluded protection：**PASS**

## 2.3 813 对文件路径完整性

-   `rgb_path`：813/813 exist
-   `thermal_path`：813/813 exist
-   `mask_path`：813/813 exist
-   All required file paths：**PASS**

## 2.4 随机 15 对实际读取

### Train（5/5 PASS）

  ----------------------------------------------------------------------------------------
  Pair        RGB             Temp          Mask                   Valid Temperature
  ----------- --------------- ------------- ------------- -------------- -----------------
  005_00072   (1216,1622,3)   (1216,1622)   (1216,1622)        100.0000% 21.85--38.80°C,
              uint8           float32       uint8                        mean 28.46

  006_00093   同上            同上          同上                99.8640% 17.68--62.48°C,
                                                                         mean 31.11

  004_00387   同上            同上          同上                99.9937% 16.50--40.73°C,
                                                                         mean 25.86

  005_00135   同上            同上          同上               100.0000% 18.33--43.54°C,
                                                                         mean 26.91

  006_00017   同上            同上          同上                99.8612% 23.36--67.16°C,
                                                                         mean 34.52
  ----------------------------------------------------------------------------------------

### Validation（5/5 PASS）

  Pair             Valid Temperature
  ----------- ---------- ----------------------------
  004_00306     99.9943% 15.94--39.76°C, mean 26.09
  004_00153     99.9935% 15.60--40.15°C, mean 25.41
  004_00559     99.9943% 12.01--40.93°C, mean 26.21
  004_00049     99.9932% 16.13--47.54°C, mean 25.05
  004_00377     99.9939% 16.33--37.64°C, mean 25.30

### Test（5/5 PASS）

  Pair              Valid Temperature
  ----------- ----------- ----------------------------
  005_00037     100.0000% 19.95--41.68°C, mean 28.31
  006_00061      99.8576% 19.98--65.82°C, mean 32.13
  005_00120     100.0000% 21.73--38.99°C, mean 28.73
  006_00054      99.8671% 15.68--47.20°C, mean 29.58
  006_00046      99.8637% 22.25--64.92°C, mean 32.54

-   Random file-read check：**15/15 PASS**

## 2.5 Dataset / DataLoader

-   Train Dataset length：613
-   Val Dataset length：31
-   Test Dataset length：35

首 batch：

-   RGB：`(4, 3, 256, 256)` torch.float32
-   Temp：`(4, 1, 256, 256)` torch.float32
-   Mask：`(4, 1, 256, 256)` torch.float32
-   Train / Val / Test DataLoader：**PASS**

环境：

-   PyTorch：1.13.1+cu116
-   CUDA available：True
-   Device：cuda
-   GPU：NVIDIA GeForce RTX 3090

## 2.6 One-batch Forward / Loss / Backward

-   Network：SmokeNet（仅训练链路测试）
-   Trainable parameters：2913
-   Patch：256×256
-   Batch：4
-   Input RGB：`(4,3,256,256)`
-   Prediction：`(4,1,256,256)`
-   Temperature target：`(4,1,256,256)`
-   Mask：`(4,1,256,256)`
-   Batch valid-mask ratio：100.000000%
-   Masked MSE loss：**755.12951660**
-   Loss finite：True

Gradient：

-   Gradient tensors：6
-   Finite gradient tensors：6
-   Non-zero gradient tensors：6
-   Total gradient L2 norm：**106.19521403**
-   Maximum absolute gradient：**54.51150513**

结果：

-   Forward：PASS
-   Prediction/target shape：PASS
-   Masked loss finite：PASS
-   Backward：PASS
-   Finite non-zero gradients：PASS

> SmokeNet 仅验证数据 / DataLoader / 训练机制链路。MSE=755.1295
> 不代表论文模型性能。256×256 是本次 smoke test
> patch，不代表最终训练尺寸已经冻结。

### 验收 2 结论

**TRAINING / DATALOADER SMOKE TEST = PASS**

------------------------------------------------------------------------

# 3. Val/Test 温度与 RGB 代表性

## 3.1 Source-subset Composition

  Source subset     Train   Val   Test
  --------------- ------- ----- ------
  004                 450    31      0
  005                 102     0     16
  006                  61     0     19

## 3.2 温度代表性

### Image-mean Temperature

  -----------------------------------------------------------------------------------
  Split           N       Mean     Median         P5        P95        Min        Max
  ------- --------- ---------- ---------- ---------- ---------- ---------- ----------
  Train         613   27.307°C   26.934°C   24.506°C   32.322°C   23.889°C   37.901°C

  Val            31   25.796°C   25.457°C   24.800°C   26.912°C   24.405°C   26.930°C

  Test           35   29.739°C   29.387°C   28.386°C   32.392°C   28.061°C   32.715°C
  -----------------------------------------------------------------------------------

### Validation vs Train

-   Median image mean：25.457°C
-   Train P5--P95：24.506--32.322°C
-   Median inside Train P5--P95：True
-   Image means inside Train min--max：100.00%
-   Pixel-temperature histogram overlap：**0.8225**
-   Temperature status：**PASS**

### Test vs Train

-   Median image mean：29.387°C
-   Train P5--P95：24.506--32.322°C
-   Median inside Train P5--P95：True
-   Image means inside Train min--max：100.00%
-   Pixel-temperature histogram overlap：**0.6868**
-   预设 overlap PASS 阈值：0.70
-   Temperature status：**REVIEW**

## 3.3 RGB 低层场景代表性

Descriptor：

-   RGB / HSV histograms
-   brightness
-   contrast
-   saturation
-   excess green
-   green fraction
-   edge density

Train empirical nearest-neighbour reference：

-   P50：0.2260
-   P95：0.5979
-   P99：1.2411
-   MAX：1.7669

### Validation → nearest Train

-   Median distance：0.3181
-   P95：0.5914
-   Maximum：0.6147
-   Train self-NN P95：0.5979
-   Train self-NN P99：1.2411
-   Samples \> Train P99：0/31（0.00%）
-   Visual support：**PASS**

### Test → nearest Train

-   Median distance：**0.7477**
-   P95：1.5089
-   Maximum：1.5702
-   Train self-NN P95：0.5979
-   Train self-NN P99：1.2411
-   Samples \> Train P99：**6/35（17.14%）**
-   Visual support：**REVIEW**

## 3.4 RGB Scene-characteristic Summary

  --------------------------------------------------------------------------
  Feature           Train median       Val median         Test median
                    (P5--P95)          (P5--P95)          (P5--P95)
  ----------------- ------------------ ------------------ ------------------
  brightness_mean   0.3913             0.4052             0.4234
                    (0.3490--0.4685)   (0.3578--0.4280)   (0.3676--0.4537)

  brightness_std    0.2872             0.2857             0.2646
                    (0.2490--0.2950)   (0.2777--0.2918)   (0.2499--0.2763)

  saturation_mean   0.3688             0.3650             0.3559
                    (0.2478--0.4168)   (0.3378--0.3902)   (0.2477--0.3883)

  excess_green      0.1623             0.1513             0.1307
                    (0.0833--0.1938)   (0.1225--0.1728)   (0.0824--0.1519)

  green_fraction    0.7673             0.6847             0.4238
                    (0.4274--0.8656)   (0.4929--0.8203)   (0.3324--0.5678)

  edge_density      0.3373             0.3332             0.3373
                    (0.3114--0.3544)   (0.3090--0.3473)   (0.3252--0.3512)
  --------------------------------------------------------------------------

## 3.5 最偏离 Train 的样本

### Validation Top 5

-   `004_00279` → `006_00034`：0.6147，\>Train P99=False
-   `004_00355` → `006_00034`：0.6008，False
-   `004_00524` → `004_00403`：0.5820，False
-   `004_00255` → `006_00034`：0.5627，False
-   `004_00527` → `004_00291`：0.5259，False

### Test Top 6（进入第 4 项客观质量检查）

-   `006_00060` → `006_00082`：**1.5702**
-   `006_00055` → `006_00082`：**1.5135**
-   `006_00059` → `006_00081`：**1.5070**
-   `006_00061` → `006_00004`：**1.3741**
-   `006_00058` → `006_00081`：**1.3140**
-   `006_00054` → `006_00082`：**1.2683**

这 6 张均高于 Train self-NN P99=1.2411。

## 3.6 Val/Test 温度极值

Validation：

-   Lowest means：004_00089 24.405°C；004_00352 24.774°C；004_00386
    24.825°C
-   Highest means：004_00279 26.930°C；004_00255 26.922°C；004_00355
    26.901°C

Test：

-   Lowest means：005_00036 28.061°C；005_00037 28.311°C；005_00038
    28.418°C
-   Highest means：006_00045 32.715°C；006_00046 32.543°C；006_00063
    32.327°C

### 验收 3 结论

-   Val temperature support：PASS
-   Test temperature support：**REVIEW**
-   Val RGB visual support：PASS
-   Test RGB visual support：**REVIEW**
-   REPRESENTATIVENESS CHECK：**REVIEW**
-   当时自动判定：`ELIGIBLE TO FREEZE 80m SPLIT = NO`

该 REVIEW 不代表数据损坏，也不否定 813 对数据；它表示 Test held-out
区域与 Train 存在值得解释的分布差异。

------------------------------------------------------------------------

# 4. 6 张差异 Test 图客观质量检查

## 4.1 检查对象

6 张图由上一项 Train self-NN P99 结果**自动确定**，不是人工挑选：

  Test Pair   Nearest Train     Descriptor distance
  ----------- --------------- ---------------------
  006_00060   006_00082                      1.5702
  006_00055   006_00082                      1.5135
  006_00059   006_00081                      1.5070
  006_00061   006_00004                      1.3741
  006_00058   006_00081                      1.3140
  006_00054   006_00082                      1.2683

-   Flagged Test images：6
-   Selection source：previous Train self-NN P99 result
-   Manual selection：NO

## 4.2 613 张 Train 图建立的 RGB 客观质量参考

  ---------------------------------------------------------------------------------------
  Metric                           P1           P5          P50          P95          P99
  ---------------------- ------------ ------------ ------------ ------------ ------------
  gray_mean                    85.420       88.644       99.353      118.789      140.184

  gray_std                     54.407       59.715       68.997       71.617       73.724

  dynamic_range_p1_p99        200.000      208.600      226.000      233.400      246.880

  black_clip                  3.3565%      3.3740%      4.7633%      4.7913%      4.8079%

  white_clip                  0.0000%      0.0000%      0.0005%      0.0228%      0.2863%

  laplacian_variance        21478.665    33284.529    45349.734    53735.036    56984.306

  tenengrad                    99.427      132.519      163.764      179.546      183.843
  ---------------------------------------------------------------------------------------

## 4.3 六张图逐张结果

### 006_00060

-   Nearest Train：006_00082
-   Descriptor distance：1.5702
-   RGB：`(1216,1622,3)` / uint8
-   Temperature：`(1216,1622)` / float32
-   Valid-mask ratio：99.8586%
-   Temperature finite：True
-   Temperature min/mean/max：19.79 / 31.45 / 65.57°C
-   Temperature std：4.074°C
-   Temp mean inside Train min-max：True
-   Brightness：113.97（Train percentile 90.5%）
-   Gray std：65.51（16.0%）
-   Dynamic range：243.00（97.2%）
-   Black clip：4.5944%
-   White clip：0.0763%
-   Laplacian variance：31798.77（4.1%）
-   Tenengrad：128.45（4.4%）
-   Focus defect：False
-   Low contrast：False
-   Exposure clipping：False
-   Data integrity：False
-   **QUALITY STATUS：PASS**

### 006_00055

-   Nearest Train：006_00082
-   Descriptor distance：1.5135
-   Valid-mask ratio：99.8616%
-   Temperature finite：True
-   Temperature min/mean/max：16.60 / 29.75 / 43.03°C
-   Temperature std：3.484°C
-   Temp mean inside Train min-max：True
-   Brightness：110.48（86.5%）
-   Gray std：65.54（16.0%）
-   Dynamic range：241.00（96.7%）
-   Black clip：4.5705%
-   White clip：0.0025%
-   Laplacian variance：30345.16（3.6%）
-   Tenengrad：128.51（4.4%）
-   所有质量缺陷 Flag：False
-   **QUALITY STATUS：PASS**

### 006_00059

-   Nearest Train：006_00081
-   Descriptor distance：1.5070
-   Valid-mask ratio：99.8627%
-   Temperature finite：True
-   Temperature min/mean/max：17.34 / 30.78 / 64.33°C
-   Temperature std：3.869°C
-   Temp mean inside Train min-max：True
-   Brightness：112.63（89.4%）
-   Gray std：66.01（18.1%）
-   Dynamic range：243.00（97.2%）
-   Black clip：4.6071%
-   White clip：0.0936%
-   Laplacian variance：31373.28（3.8%）
-   Tenengrad：127.64（4.4%）
-   所有质量缺陷 Flag：False
-   **QUALITY STATUS：PASS**

### 006_00061

-   Nearest Train：006_00004
-   Descriptor distance：1.3741
-   Valid-mask ratio：99.8576%
-   Temperature finite：True
-   Temperature min/mean/max：19.98 / 32.13 / 65.82°C
-   Temperature std：4.104°C
-   Temp mean inside Train min-max：True
-   Brightness：113.27（89.6%）
-   Gray std：66.06（18.3%）
-   Dynamic range：241.00（96.7%）
-   Black clip：4.6570%
-   White clip：0.0575%
-   Laplacian variance：31779.74（4.1%）
-   Tenengrad：127.40（4.4%）
-   所有质量缺陷 Flag：False
-   **QUALITY STATUS：PASS**

### 006_00058

-   Nearest Train：006_00081
-   Descriptor distance：1.3140
-   Valid-mask ratio：99.8649%
-   Temperature finite：True
-   Temperature min/mean/max：15.76 / 30.28 / 45.83°C
-   Temperature std：3.663°C
-   Temp mean inside Train min-max：True
-   Brightness：115.12（92.2%）
-   Gray std：65.62（16.2%）
-   Dynamic range：244.00（97.7%）
-   Black clip：4.5664%
-   White clip：0.2014%
-   Laplacian variance：31241.35（3.8%）
-   Tenengrad：129.74（4.6%）
-   所有质量缺陷 Flag：False
-   **QUALITY STATUS：PASS**

### 006_00054

-   Nearest Train：006_00082
-   Descriptor distance：1.2683
-   Valid-mask ratio：99.8671%
-   Temperature finite：True
-   Temperature min/mean/max：15.68 / 29.58 / 47.20°C
-   Temperature std：3.461°C
-   Temp mean inside Train min-max：True
-   Brightness：108.80（84.2%）
-   Gray std：66.13（18.8%）
-   Dynamic range：241.00（96.7%）
-   Black clip：4.5868%
-   White clip：0.0051%
-   Laplacian variance：33227.50（5.1%）
-   Tenengrad：133.17（5.1%）
-   所有质量缺陷 Flag：False
-   **QUALITY STATUS：PASS**

## 4.4 六图汇总

-   Images checked：6
-   PASS：**6**
-   REVIEW：0
-   FAIL：0
-   Focus-defect flags：0
-   Low-contrast flags：0
-   Exposure-clipping flags：0
-   Data-integrity failures：0

### 验收 4 结论

**SERVER FINAL SIX-IMAGE QUALITY ANSWER = PASS**

六张与 Train 低层视觉分布差异最大的 Test 图均通过客观数据质量筛查。

没有证据表明它们与 Train 的差异由以下问题造成：

-   文件损坏；
-   严重模糊；
-   严重低对比度；
-   明显曝光裁剪；
-   无效 Thermal；
-   无效 Mask。

因此，第 3 项 Test representativeness 的 REVIEW
**更符合真实场景/分布差异，而不是明显图像质量缺陷**。

------------------------------------------------------------------------

# 5. 四步检查后的当前结论

## 已确认

1.  **空间边界自动重叠检查 PASS**：612 个近边界跨 split Pair 中
    CLEAR_OVERLAP=0、REVIEW=0。
2.  **训练数据链 PASS**：813/813 文件存在；`split` 为实际读取列；134
    excluded 未进入 active；Train/Val/Test
    DataLoader、forward、loss、backward 和 gradient 均正常。
3.  **Validation 代表性 PASS**：温度与 RGB 低层视觉支持均通过。
4.  **Test 代表性仍为 REVIEW**：温度直方图 overlap=0.6868，略低于预设
    0.70；RGB nearest-Train median=0.7477，高于 Train self-NN
    P95=0.5979；6/35 超过 Train self-NN P99。
5.  **6 张 Test 差异图质量 PASS**：6/6 无客观质量缺陷，因此 Test
    的差异不应简单解释为坏图。

## 当前科学解释

现有证据支持：

> Test held-out 区域相对于 Train
> 存在真实的场景/温度分布差异，但其文件、RGB质量、Thermal有效性和 Mask
> 完整性正常。

这类差异可以成为空间泛化测试的一部分，但是否据此正式冻结 80 m
split，属于下一步实验设计/论文口径决定，不能通过第 4 项质量 PASS
自动替代第 3 项的 representativeness REVIEW。

## 数据状态

-   原始验收后的 813 对数据：**不需要重新处理**
-   RGB / Temperature / Mask：**未修改**
-   当前 `split`：**未修改**
-   Excluded 134：**保留**
-   当前 candidate Manifest：**保留**
