# Cynthia Dataset --- DATA READY Final Acceptance Report

**Date:** 2026-09-18\
**Task:** RGB → Temperature Map training-data preparation and
acceptance\
**Final status:** **DATA READY --- PASS**

------------------------------------------------------------------------

## 1. Final conclusion

The current Cynthia dataset **meets the data-layer requirements for
baseline model training**.

The final usable dataset contains **813 aligned RGB--temperature
pairs**. Each training pair consists of:

-   **Input X:** Stage1 processed RGB image
-   **Label Y:** Stage3 registered float32 temperature map
-   **Valid Mask:** mask for excluding invalid warp/no-data boundary
    pixels from the loss
-   **Manifest:** file paths, subset, sequence information, valid ratio,
    temperature statistics, group/split information

The data have passed structural validation, numerical validation,
Stage2→Stage3 temperature-preservation checks, duplicate checks, SDK
consistency sampling, visual RGB↔temperature registration QC, valid-mask
acceptance, full-file reading, and DataLoader/batch smoke testing.

Therefore, **no further Cynthia preprocessing is required before
starting the baseline model experiment**.

> **DATA READY --- Cynthia data have completed preprocessing and
> acceptance and can enter baseline training.**

### Important methodological limitation

004, 005 and 006 are segments from the **same 2022-08-30 Cynthia
flight**, not three independent flights under different environmental
conditions. The current split is safer than randomly mixing adjacent UAV
frames, but it must **not** be described in the thesis as an independent
cross-flight or cross-condition generalization test.

------------------------------------------------------------------------

## 2. Final training data composition

  Item                                             Result
  ------------------------------------- -----------------
  Original Aug-30 RGB--thermal pairs                  814
  Final usable RGB--temperature pairs             **813**
  004 usable pairs                                **570**
  005 usable pairs                                **149**
  006 usable pairs                                 **94**
  Final RGB size                          **1622 × 1216**
  Final temperature-map size              **1622 × 1216**
  Temperature dtype                           **float32**
  Stage2 thermal size                       **640 × 512**
  NaN/Inf in accepted data                          **0**

The original flight contains 814 pairs. The final accepted set contains
813 pairs because Stage1/ODM retained 570 RGB images from subset 004
while Stage3 contains 571 thermal outputs. The unmatched `004 img_00006`
has no final RGB counterpart and is therefore excluded instead of being
forced into the training set.

------------------------------------------------------------------------

## 3. What exactly will be used for training

### 3.1 RGB input

**Source:** Stage1 RGB output

Server paths:

``` text
/root/autodl-fs/data/cynthia_004_output/combined/opensfm/undistorted/images_rgb
/root/autodl-fs/data/cynthia_005_output/combined/opensfm/undistorted/images_rgb
/root/autodl-fs/data/cynthia_006_output/combined/opensfm/undistorted/images_rgb
```

**Meaning:** RGB images after the Cynthia pipeline's RGB
preprocessing/undistortion/cropping.

**Training role:** Model input `X`.

**Final size:** `1622 × 1216`, Python array shape normally
`(1216, 1622, 3)`.

------------------------------------------------------------------------

### 3.2 Temperature label

**Source:** Stage3 registered thermal output

Server paths:

``` text
/root/autodl-fs/data/cynthia_004_output/combined/opensfm/undistorted/images
/root/autodl-fs/data/cynthia_005_output/combined/opensfm/undistorted/images
/root/autodl-fs/data/cynthia_006_output/combined/opensfm/undistorted/images
```

**Meaning:** Stage2 radiometric temperature maps registered into the
Stage1 RGB coordinate system.

**Training role:** Ground-truth temperature label `Y`.

**Final size:** `1622 × 1216`, Python array shape `(1216, 1622)`.

**dtype:** `float32`.

These files contain temperature values and are not ordinary pseudo-color
thermal pictures.

------------------------------------------------------------------------

### 3.3 Valid Mask

Server path:

``` text
/root/autodl-fs/data/cynthia_train_ready/masks
```

**Meaning:** Identifies pixels accepted as valid temperature supervision
and excludes invalid warp/no-data boundary pixels.

**Training role:** Used in masked loss. Invalid pixels must not
contribute to the RGB→temperature regression loss.

Final mask statistics:

  -----------------------------------------------------------------------
  Subset                   N  Minimum valid   Median valid     Mean valid
                                      ratio          ratio          ratio
  ----------- -------------- -------------- -------------- --------------
  004                    570       99.9913%       99.9937%       99.9937%

  005                    149      100.0000%      100.0000%      100.0000%

  006                     94       99.8528%       99.8630%       99.8632%

  ALL                    813   **99.8528%**   **99.9938%**   **99.9797%**
  -----------------------------------------------------------------------

Additional checks:

``` text
Mask <99% = 0
Mask <95% = 0
```

Conclusion: the mask removes only a very small boundary fraction and
does not remove large valid regions.

------------------------------------------------------------------------

### 3.4 Manifest / split index

Server directory:

``` text
/root/autodl-fs/data/cynthia_train_ready/manifest
```

Main file:

``` text
cynthia_final_manifest.csv
```

Split files:

``` text
train.csv
val.csv
test.csv
```

The manifest records the RGB path, Stage3 temperature path, mask path,
subset, sequence information, valid ratio, temperature statistics, group
ID and split.

Current split:

  Split        Source subset      Number
  ------------ --------------- ---------
  Train        004               **570**
  Validation   005               **149**
  Test         006                **94**
  Total        ---               **813**

This is the current baseline split. Because the three subsets belong to
the same flight, this split should be described as a
**flight-segment/grouped split**, not an independent cross-flight test.

------------------------------------------------------------------------

## 4. Evidence used to decide that the data are train-ready

### 4.1 Pair-count and structure acceptance --- PASS

Final candidate pairs:

``` text
004 = 570
005 = 149
006 = 94
TOTAL = 813
```

Accepted RGB and Stage3 files have matching IDs in the final manifest.

------------------------------------------------------------------------

### 4.2 Shape / dtype / NaN / Inf acceptance --- PASS

For the accepted pairs:

-   RGB shape is consistent with `1622 × 1216`
-   Stage3 temperature shape is consistent with `1622 × 1216`
-   Stage3 temperature dtype is `float32`
-   Shape errors = 0
-   dtype errors = 0
-   NaN files = 0
-   Inf files = 0

------------------------------------------------------------------------

### 4.3 004 pairing repair and revalidation --- PASS

004 previously had a filename/order problem caused by unsafe in-place
renaming and unsorted file ordering.

The final repair used:

``` text
current img ID
→ current RGB EXIF time
→ original _W.JPG
→ original W sequence
→ same-sequence thermal RAW
```

A strict one-to-one mapping was established for the 571 source
relationships, and the final RGB intersection contains 570 usable pairs.

The final 004 Stage3 valid area is effectively 100%, replacing the
earlier obviously incorrect \~20.55% result.

The mapping evidence is stored in:

``` text
/root/autodl-fs/data/cynthia_004_output/004_pair_mapping.csv
```

------------------------------------------------------------------------

### 4.4 Warp / abnormal low-temperature boundary audit --- PASS

The earlier low-temperature audit showed that abnormal very-low values
are confined to a very small fraction of pixels, consistent with
warp/interpolation boundary effects rather than widespread corrupted
temperature data.

Key observations:

-   005: no pixels below 15°C in the audit
-   006: `<1°C` approximately 0.1117% of pixels
-   004: `<1°C` approximately 0.0023% of pixels

These boundary pixels are handled by the valid mask rather than deleting
complete images.

------------------------------------------------------------------------

### 4.5 Stage2 ↔ Stage3 temperature preservation --- PASS

Stage2 is the `640 × 512` radiometric temperature result. Stage3
registers/resamples it to the RGB coordinate system.

Final statistics:

  Subset        Mean Δ        MAE   P95 absolute Δ   Maximum absolute Δ
  -------- ----------- ---------- ---------------- --------------------
  006        +0.0386°C   0.1379°C         0.3837°C             0.5879°C
  005        -0.0445°C   0.1030°C         0.3404°C             0.6761°C
  004        -0.0271°C   0.0590°C         0.1456°C             0.2904°C

**Result: PASS.**

Interpretation: Stage3 registration/resampling did not introduce a
material systematic temperature shift in the accepted dataset.

Detailed CSV:

``` text
/root/autodl-fs/data/cynthia_train_ready/qc/stage2_stage3_temperature_check.csv
```

------------------------------------------------------------------------

### 4.6 006 DJI TSDK v1.4 ↔ v1.8 consistency sample --- PASS

A same-image, same-parameter comparison was performed on sequence
`0048`.

Result:

``` text
mean difference = 0.00000°C
MAE             = 0.00000°C
RMSE            = 0.00000°C
P95             = 0.00000°C
P99             = 0.00000°C
max difference  = 0.00000°C
```

**Result: PASS.**

This supports retaining the already processed 006 data instead of
rerunning Stage2/Stage3 solely for SDK-version consistency.

This is a sampled SDK consistency check, not a claim that every possible
SDK input is universally identical.

------------------------------------------------------------------------

### 4.7 Duplicate / leakage-oriented check --- PASS for tested conditions

Automatic results:

``` text
Exact RGB duplicate groups = 0
Exact Thermal duplicate groups = 0
Cross-split very-similar dHash pairs (distance <= 2) = 0
Exact duplicates = PASS
```

This rules out exact duplicates and the tested class of extremely
similar cross-split frames.

It does **not** prove that the test set is independent of the training
flight, because 004/005/006 are still segments of the same flight.

Evidence file:

``` text
/root/autodl-fs/data/cynthia_train_ready/qc/duplicate_check.txt
```

------------------------------------------------------------------------

### 4.8 RGB ↔ Temperature visual registration QC --- PASS

18 representative RGB / thermal / overlay samples were generated across
004, 005 and 006.

Visual review found no obvious whole-image mismatch, gross translation,
wrong rotation, or pairing error. Major canopy structures, gaps,
roads/open areas and other large spatial structures were consistent
between RGB and registered thermal images.

**Result: PASS for training-data visual QC.**

Important wording: this visual QC supports **absence of obvious
macro-registration errors**. It should not be presented as proof of
mathematically exact sub-pixel registration.

Montage:

``` text
/root/autodl-fs/data/cynthia_train_ready/qc/Cynthia_Visual_QC_Montage.jpg
```

Individual QC images:

``` text
/root/autodl-fs/data/cynthia_train_ready/qc/visual_qc
```

------------------------------------------------------------------------

### 4.9 Full 813-pair read test --- PASS

``` text
read 813/813
Full-read errors = 0
Full read = PASS
```

This verifies that all files referenced by the final training dataset
can be opened and that the expected RGB, temperature and mask structures
are available.

------------------------------------------------------------------------

### 4.10 DataLoader / batch smoke test --- PASS

A real batch was read from the prepared training data using a
synchronized `256 × 256` crop.

Results:

``` text
RGB batch  = (4, 3, 256, 256)  torch.float32
Temp batch = (4, 1, 256, 256)  torch.float32
Mask batch = (4, 1, 256, 256)  torch.float32
DataLoader = PASS
```

Masked-loss calculation also completed successfully.

This confirms that the prepared RGB, temperature and mask data can enter
the PyTorch data pipeline.

The `256 × 256` size here is a **smoke-test / candidate patch size**.
The original accepted files remain `1622 × 1216`; the final baseline
training crop/patch strategy can still be set in the model experiment.

------------------------------------------------------------------------

## 5. Final acceptance table

  Acceptance item                               Result
  --------------------------------------------- ----------------
  004 pairing repair                            PASS
  Final RGB↔Stage3 pairs = 813                  PASS
  Shape consistency                             PASS
  Temperature dtype                             PASS
  NaN / Inf                                     PASS
  Warp/low-temperature boundary audit           PASS
  Stage2↔Stage3 temperature preservation        PASS
  006 SDK v1.4↔v1.8 sample consistency          PASS
  Exact duplicate check                         PASS
  Tested cross-split extreme-similarity check   PASS
  RGB↔Temperature visual QC                     PASS
  Valid Mask acceptance                         PASS
  Final Manifest                                PASS
  Current grouped split files                   PASS
  Full 813-pair read                            PASS
  DataLoader / batch smoke test                 PASS
  **Overall data-layer status**                 **DATA READY**

------------------------------------------------------------------------

# 6. What must be downloaded / backed up

This section distinguishes **training-essential data**, **acceptance
evidence**, and **reproducibility/archive data**.

## A. MUST DOWNLOAD --- required to train elsewhere

### A1. Final Stage1 RGB images

Download these three directories:

``` text
/root/autodl-fs/data/cynthia_004_output/combined/opensfm/undistorted/images_rgb
/root/autodl-fs/data/cynthia_005_output/combined/opensfm/undistorted/images_rgb
/root/autodl-fs/data/cynthia_006_output/combined/opensfm/undistorted/images_rgb
```

**What they are:** final RGB inputs.

**Used as:** model `X`.

------------------------------------------------------------------------

### A2. Final Stage3 temperature maps

Download these three directories:

``` text
/root/autodl-fs/data/cynthia_004_output/combined/opensfm/undistorted/images
/root/autodl-fs/data/cynthia_005_output/combined/opensfm/undistorted/images
/root/autodl-fs/data/cynthia_006_output/combined/opensfm/undistorted/images
```

**What they are:** RGB-registered float32 temperature maps.

**Used as:** model ground-truth `Y`.

**Important:** These are the temperature labels actually used for
training. Do not substitute Stage2 TIFFs directly for Stage3 labels
because Stage2 is still `640 × 512` and is not yet in the final RGB
coordinate system.

------------------------------------------------------------------------

### A3. Final masks

Download:

``` text
/root/autodl-fs/data/cynthia_train_ready/masks
```

**What they are:** valid-pixel masks.

**Used as:** masked-loss validity mask.

------------------------------------------------------------------------

### A4. Final manifest and split CSV files

Download:

``` text
/root/autodl-fs/data/cynthia_train_ready/manifest
```

Especially:

``` text
cynthia_final_manifest.csv
train.csv
val.csv
test.csv
```

**What they are:** the final index connecting RGB, temperature, mask,
subset, sequence/group and split.

**Used as:** Dataset/DataLoader input index and experiment traceability.

------------------------------------------------------------------------

## B. STRONGLY RECOMMENDED DOWNLOAD --- acceptance evidence

Download:

``` text
/root/autodl-fs/data/cynthia_train_ready/qc
```

Important files include:

``` text
final_report.txt
stage2_stage3_temperature_check.csv
duplicate_check.txt
Cynthia_Visual_QC_Montage.jpg
visual_qc/
sdk_compare/
```

**What they are:** evidence showing why the dataset was accepted as
train-ready.

**Used for:** thesis records, later troubleshooting, defending
preprocessing decisions, and avoiding the need to rerun acceptance
checks.

------------------------------------------------------------------------

## C. STRONGLY RECOMMENDED DOWNLOAD --- 004 repair evidence

Download:

``` text
/root/autodl-fs/data/cynthia_004_output/004_pair_mapping.csv
```

**What it is:** the mapping record used to repair the 004 RGB↔thermal
identity problem.

**Used for:** reproducibility and explaining why the final 004 pairing
is trustworthy.

------------------------------------------------------------------------

## D. RECOMMENDED ARCHIVE --- Stage2 temperature data

Download or retain a backup of:

``` text
/root/autodl-fs/data/cynthia_004_output/thermal/images
/root/autodl-fs/data/cynthia_005_output/thermal/images
/root/autodl-fs/data/cynthia_006_output/thermal/images
```

**What they are:** `640 × 512` float32 temperature maps produced from
the radiometric source before Stage3 registration.

**Used for:** checking temperature extraction, comparing Stage2 with
Stage3, and future preprocessing verification.

**Not the direct training label** in the current RGB→temperature
experiment.

------------------------------------------------------------------------

## E. REPRODUCIBILITY ARCHIVE --- RAW / original radiometric source

If local copies do not already exist, retain the Stage2 RAW files and
original H20T `_T.JPG` R-JPEG data.

**What they are:**

``` text
R-JPEG (_T.JPG)
→ DJI TSDK measure
→ float32 RAW temperature matrix
→ Stage2 TIFF
→ Stage3 registered temperature map
```

**Used for:** rebuilding temperature labels from the original
radiometric source if the processing pipeline or parameters must be
reproduced later.

These files are important for full reproducibility, but they are **not
required for ordinary baseline training once the accepted Stage3 labels
are safely backed up**.

------------------------------------------------------------------------

## 7. Minimum local backup set

If storage is limited, the minimum set that should be downloaded before
relying on the server is:

``` text
1. 004/005/006 Stage1 images_rgb      → training RGB X
2. 004/005/006 Stage3 images          → temperature Y
3. cynthia_train_ready/masks          → valid-pixel mask
4. cynthia_train_ready/manifest       → pairing + split index
5. cynthia_train_ready/qc             → acceptance evidence
6. 004_pair_mapping.csv               → critical 004 repair evidence
```

If the original R-JPEG/RAW/Stage2 data are **not already safely stored
elsewhere**, also archive them.

------------------------------------------------------------------------

## 8. Server-side data map

``` text
/root/autodl-fs/data/
│
├── cynthia_004_output/
│   ├── combined/opensfm/undistorted/images_rgb/   ← RGB X
│   ├── combined/opensfm/undistorted/images/       ← Stage3 temperature Y
│   ├── thermal/images/                            ← Stage2 temperature
│   ├── thermal/raw/                               ← temperature RAW
│   └── 004_pair_mapping.csv                       ← 004 repair evidence
│
├── cynthia_005_output/
│   ├── combined/opensfm/undistorted/images_rgb/   ← RGB X
│   ├── combined/opensfm/undistorted/images/       ← Stage3 temperature Y
│   ├── thermal/images/                            ← Stage2 temperature
│   └── thermal/raw/                               ← temperature RAW
│
├── cynthia_006_output/
│   ├── combined/opensfm/undistorted/images_rgb/   ← RGB X
│   ├── combined/opensfm/undistorted/images/       ← Stage3 temperature Y
│   ├── thermal/images/                            ← Stage2 temperature
│   └── thermal/raw/                               ← temperature RAW
│
└── cynthia_train_ready/
    ├── manifest/
    │   ├── cynthia_final_manifest.csv             ← complete index
    │   ├── train.csv                              ← current train split
    │   ├── val.csv                                ← current validation split
    │   └── test.csv                               ← current test split
    │
    ├── masks/                                     ← valid-pixel masks
    │
    └── qc/
        ├── final_report.txt                       ← automatic acceptance report
        ├── stage2_stage3_temperature_check.csv    ← temperature-preservation evidence
        ├── duplicate_check.txt                    ← duplicate/similarity evidence
        ├── Cynthia_Visual_QC_Montage.jpg          ← visual registration montage
        ├── visual_qc/                             ← individual QC images
        └── sdk_compare/                           ← SDK consistency evidence
```

------------------------------------------------------------------------

## 9. What should NOT be confused

1.  **Stage2 TIFF is not the final training label.**\
    Stage2 contains real temperature values but remains `640 × 512`. The
    current training label is the Stage3 registered `1622 × 1216`
    temperature map.

2.  **Stage3 is not a pseudo-color image.**\
    It is a float32 temperature field used as regression ground truth.

3.  **The mask is not a second model input.**\
    It is used to decide which label pixels participate in the loss.

4.  **The 256 × 256 batch smoke test does not mean the original dataset
    was permanently resized.**\
    Original accepted RGB and temperature maps remain `1622 × 1216`.

5.  **Train/Val/Test being different 004/005/006 folders does not make
    them different flights.**\
    They are segments of the same Aug-30 flight. This must be stated
    accurately in the thesis.

------------------------------------------------------------------------

# 10. Final status

## **DATA READY --- PASS**

The Cynthia dataset has completed the current data-processing and
acceptance stage.

**Final usable data: 813 RGB--temperature pairs.**

The accepted training data provide:

``` text
RGB X
+
registered float32 temperature Y
+
valid mask
+
manifest/split index
```

and have passed the required data-layer integrity and loading checks.

**Next project stage: baseline model training.**
