# Cynthia 数据集：从当前处理结果到"可直接训练"的总进度记录

**创建日期：2026-09-18**\
**任务范围：本文件覆盖 Cynthia 2022-08-30 数据从当前 Stage1/2/3
结果开始，直到数据被完整处理、最终验收、分组划分并达到可直接用于模型训练的状态。**\
**结束条件：不是"验收完原始输出"就结束，而是最终形成可直接被训练程序读取的
RGB + Temperature + Mask + Manifest + Split
数据体系，并完成训练前数据加载冒烟测试。**

------------------------------------------------------------------------

# 0. 最终目标

把当前 Cynthia 数据处理到以下状态：

1.  最终有效 RGB--Temperature Pair 数量确定且一一对应。
2.  RGB 与温度标签的空间配准、温度数值、文件健康全部验收通过。
3.  处理 SDK 版本一致性问题。
4.  检查重复帧、近重复/连续帧，建立序列/空间分组依据。
5.  生成有效像素 Mask，避免 Stage3 warp 边缘无效值进入监督损失。
6.  建立唯一的最终 Manifest。
7.  根据连续航拍关系完成 Train / Val / Test
    分组，避免相邻高重叠帧随机泄漏。
8.  保留原始 1622×1216 Pair，不破坏原数据；确定训练时 crop / patch /
    resize 策略。
9.  建立最终训练数据目录/索引。
10. 对全部训练数据执行读取检查，并完成 DataLoader / batch 级冒烟测试。
11. 保存最终验收表、Manifest、Split、Mask 规则和关键处理记录。
12. 最终状态明确标记为：**DATA READY --- 可以开始 baseline 训练。**

------------------------------------------------------------------------

# 1. 数据来源与处理链

数据：Cynthia 2022-08-30。

设备： - DJI Matrice 300 RTK - DJI Zenmuse H20T - 同时采集 Wide RGB 与
radiometric thermal R-JPEG

当前模型任务：

**RGB → 逐像素温度图**

训练时： - X = Stage1 处理后的 RGB - Y = Stage3 配准后的真实温度图 -
Thermal 只作为训练标签，不作为模型推理输入

处理链：

`原始 W.JPG → Stage1 → RGB`

`原始 T.JPG (R-JPEG) → DJI Thermal SDK → RAW float32 温度矩阵 → Stage2 TIFF → Stage3 配准 → Temperature Label`

当前最终 Pair 原始尺寸： - RGB：1622×1216×3 - Temperature：1622×1216 -
Python shape：RGB `(1216,1622,3)`；Temperature `(1216,1622)`

Stage4 热红外 orthomosaic 不属于当前单图 RGB→温度模型训练所需数据。

------------------------------------------------------------------------

# 2. 已完成的数据处理与验收

## 2.1 004 配对异常修复 --- PASS

004 曾发现： 1. 原项目无序 `os.listdir()` + 原地重命名造成 thermal TIFF
文件覆盖/错号。 2. Stage1 RGB 编号与原始 W/T 序列错配。 3. 错配时 Stage3
有效区域仅约 20.55%，NGF 变换异常。

最终建立严格映射：

`当前 Stage1 RGB EXIF → 原始 W EXIF → 原始 W sequence → 同 sequence Thermal RAW`

保存： `004_pair_mapping.csv`

映射： - 当前 RGB：571 - 原始 W：571 - RAW：571 - 严格一对一：571 -
缺失/重复匹配：0

重新按正确映射生成 Stage2 TIFF，并重新执行 Stage3。

修复后： - Stage1 RGB = 570 - Stage3 = 571 - 最终 Pair = 570 - 只有
Stage3 = `00006` - shape 错误 = 0 - dtype 错误 = 0 - NaN = 0 - Inf = 0 -
Stage3 有效区域 = 100% - **PASS**

004 不再重新运行已经通过的 Stage1/2/3。

## 2.2 006 / 005 / 004 合并结构检查 --- PASS

  子集             RGB   Stage3   最终 Pair   有效区域 结果
  ---------- --------- -------- ----------- ---------- ----------
  006               94       94          94     99.89% PASS
  005              149      149         149       100% PASS
  004              570      571         570       100% PASS
  **合计**     **813**      ---     **813**        --- **PASS**

原始 Aug.30 共 814 对；004 的 `00006` 无对应 Stage1
RGB，因此最终有效候选训练 Pair 为：

**813 Pair**

不人为补齐缺失 RGB。

文件健康： - shape 错误 = 0 - dtype 错误 = 0 - NaN = 0 - Inf = 0

## 2.3 当前温度统计 --- PASS（基础检查）

006： - 全局最低约 1.0001°C（另有 warp 0 值） - 全局最高约 73.6786°C -
图像均温约 28.2799--37.8940°C - 图像均温中位约 31.5002°C

005： - 全局最低约 15.0924°C - 全局最高约 69.3419°C - 图像均温约
26.4217--33.6677°C - 图像均温中位约 28.2368°C

004： - 全局最低约 1.0001°C（另有 warp 0 值） - 全局最高约 62.4977°C -
图像均温约 23.7880--28.4119°C - 图像均温中位约 26.4476°C

## 2.4 极端低温 / warp 无效边缘检查 --- PASS

006： - `<1°C` = 0.11165792% - `1–5°C` = 0.00566555% - `5–10°C` =
0.00704149% - `10–15°C` = 0.00713426%

005： - `<1°C` = 0 - `1–5°C` = 0 - `5–10°C` = 0 - `10–15°C` = 0

004： - `<1°C` = 0.00228562% - `1–5°C` = 0.00099395% - `5–10°C` =
0.00124088% - `10–15°C` = 0.01177362%

当前结论： - 不因少量边缘低值删除整张图。 - 006 的低值比例与其约 99.89%
Stage3 有效区域相符，主要表现为 warp 边缘。 - 训练前必须生成明确的 valid
mask。 - 不机械地把所有 10--15°C 像素判为错误温度。

------------------------------------------------------------------------

# 3. 剩余工作：一直做到"可直接训练"

以下项目不是可选待办，而是本次数据任务继续执行的完整范围。

## STEP 1 --- Stage2 ↔ Stage3 温度保持性验收

**状态：待执行**

目的： 确认 Stage3 的 resize、affine warp、interpolation
没有造成明显系统性温度漂移。

对每个可匹配样本统计： - Stage2 min / max / mean - Stage3 valid-region
min / max / mean - `ΔMean` - `|ΔMean|` - 必要时温度分位数

对子集汇总： - Mean Δ - MAE of image mean - P95 - 最大绝对均温差 -
异常样本 ID

输出： - `stage2_stage3_temperature_check.csv` - 总结结果写入最终验收 MD

判定： - 不要求 Stage2 与 Stage3 逐像素相同，因为 Stage3 有
resize/warp/interpolation。 - 要求整体温度统计不存在明显系统性漂移。 -
异常样本必须定位并解释/处理后才能进入下一阶段。

------------------------------------------------------------------------

## STEP 2 --- 006 DJI TSDK v1.4 ↔ v1.8 一致性验收

**状态：待执行**

当前版本： - 006：TSDK v1.4 - 005：TSDK v1.8 - 004：TSDK v1.8

使用 006 的同一原始 R-JPEG，在完全相同参数下重新由 v1.8 提取，并与当前
v1.4 温度 RAW 比较。

参数保持： - emissivity = 0.95 - humidity = 46.3% - reflected
temperature = 25.4°C - SDK distance = 25.0 m（CLI 上限；论文条件为 \>25
m）

统计： - Mean difference - MAE - RMSE - Max absolute difference - P50 /
P95 / P99 absolute difference

判定分支： - 若差异可忽略：保留当前 006，不重跑。 -
若存在明显系统差异：统一使用 v1.8 重跑 006 Stage2 +
Stage3，并重新执行受影响验收项目。

输出： - SDK 对照统计 - 最终使用版本说明 - 写入最终 MD

------------------------------------------------------------------------

## STEP 3 --- 重复、近重复与连续航拍序列检查

**状态：待执行**

检查： 1. 完全重复 RGB。 2. 完全重复 Thermal。 3. RGB Pair / Thermal
Pair 是否出现重复映射。 4. 近重复/高度相似连续帧。 5. 原始 sequence /
EXIF 时间连续性。 6. 004 / 005 / 006 的时间和序列边界。 7.
为后续空间/序列分组生成依据。

重点： 本数据为高重叠连续无人机航拍。相邻帧很可能观察同一地面区域。

因此后续： **禁止直接对 813 张图片逐帧随机打乱后划分 Train/Val/Test。**

否则可能出现： - Train：相邻帧 A - Val：相邻帧 B - A/B
大量空间内容重叠 - 验证指标被数据泄漏抬高

输出： - duplicate/sequence 检查结果 - `group_id` 或序列分组依据 -
异常样本清单（若有）

------------------------------------------------------------------------

## STEP 4 --- RGB ↔ Temperature 空间配准视觉最终验收

**状态：待执行**

自动生成约 15--20 个代表性 Pair 的视觉检查图。

抽样： - 006：前 / 中 / 后 - 005：前 / 中 / 后 - 004：前 / 中 /
后，并增加样本 - 加入自动统计发现的可疑样本

检查： - 树冠边缘 - 道路/空地区域 - 明显高低温结构 - RGB 与 Thermal
的整体旋转、平移、缩放 - 是否存在局部/整幅明显错位

输出： - `visual_qc/` - 抽查样本 ID 清单 - 最终视觉结论

判定： 只有视觉抽查无明显系统性错配，才能确认 Stage3
数据可作为逐像素监督标签。

------------------------------------------------------------------------

## STEP 5 --- 生成最终 Valid Mask

**状态：待执行**

目的： 把 Stage3 warp 产生的无效边缘从训练监督中排除。

原则： - 不直接修改原始 Stage3 float32 TIFF。 - 单独生成 mask。 - mask
与 Temperature 尺寸严格一致。 - 有效像素 = 1，无效像素 = 0。 - 不把明显
warp 产生的 0 / 无效边缘作为真实低温标签。 - mask
规则必须根据前述温度/边缘检查最终确定并记录，避免误删真实低温像素。

输出： - 每个 Pair 对应 mask，或可由 Manifest + 明确规则稳定复现。 -
Mask 数量 = 最终 Pair 数。 - Mask shape = `(1216,1622)`。 - Mask 文件与
Pair ID 一一对应。

验收： - mask 缺失 = 0 - shape 错误 = 0 - 全空 mask = 0 - valid ratio
分布正常

------------------------------------------------------------------------

## STEP 6 --- 建立最终 813 Pair Manifest

**状态：待执行**

最终 Manifest 至少包含：

-   `pair_id`
-   `subset`
-   `sequence_id`
-   `rgb_path`
-   `thermal_path`
-   `mask_path`
-   `rgb_width`
-   `rgb_height`
-   `thermal_width`
-   `thermal_height`
-   `valid_ratio`
-   `temp_min_valid`
-   `temp_max_valid`
-   `temp_mean_valid`
-   `group_id`
-   `split`

要求： - Pair ID 唯一 - RGB 唯一 - Thermal 唯一 - Mask 唯一 - 路径存在 -
最终行数与最终可训练 Pair 数一致 - 004 `00006` 不进入最终训练 Manifest

输出： - `cynthia_final_manifest.csv`

------------------------------------------------------------------------

## STEP 7 --- Train / Val / Test 分组与划分

**状态：待执行**

目标： 在不发生连续帧/空间泄漏的前提下划分训练、验证、测试数据。

不是直接： `random_split(813)`

而是先根据 STEP 3 建立的连续/空间关系形成 `group_id`，再按 group 划分。

需要最终确定： - Train 数量 - Val 数量 - Test 数量 - 每个 subset 在各
split 中的分布 - group 是否跨 split - 相邻高重叠帧是否跨 split

硬性检查： - 同一 group 不跨 Train/Val/Test。 - Pair 无重复。 -
Train/Val/Test 交集 = 0。 - Train + Val + Test = 最终 Pair 总数。

输出： - `cynthia_final_manifest.csv` 中写入 `split` - 单独可保存
`train.csv` / `val.csv` / `test.csv`

------------------------------------------------------------------------

## STEP 8 --- 确定模型训练输入尺寸 / Patch 策略

**状态：待执行**

原始最终 Pair 保持： **1622×1216**

不直接破坏或覆盖原图。

训练输入尺寸需要结合： - baseline 网络要求 - GPU 显存 -
是否需要保持局部温度结构 - 论文对照实验的统一性

候选： - 256×256 patch - 512×512 patch - 其他经实验设计确定的输入

原则： - RGB 与 Temperature 必须使用完全相同的空间 crop。 - Mask 同步
crop。 - 不允许 RGB 和 label 独立随机裁剪。 -
数据增强若包含翻转/旋转等空间变换，也必须对 RGB / Temperature / Mask
同步执行。 - 温度标签保持 float32，不作为普通 8-bit 图像处理。 - 原始
1622×1216 Pair 永久保留，patch
可训练时动态生成或另建派生数据，不覆盖原数据。

输出： - 明确训练输入尺寸 - 明确 crop/patch 方法 - 明确是否动态采样 -
写入训练数据说明

------------------------------------------------------------------------

## STEP 9 --- 建立最终"可训练数据"目录/索引

**状态：待执行**

推荐逻辑结构：

``` text
cynthia_train_ready/
├── manifest/
│   ├── cynthia_final_manifest.csv
│   ├── train.csv
│   ├── val.csv
│   └── test.csv
├── masks/
│   └── ...
├── qc/
│   ├── stage2_stage3_temperature_check.csv
│   ├── visual_qc/
│   └── final_acceptance.md
└── README.md
```

RGB / Thermal 可以： - 保留原正式输出路径并由 Manifest 引用；或 -
在确认磁盘/下载方案后建立只包含最终 Pair 的训练目录。

原则： 不为了"看起来整齐"重复复制大量数据，优先保证： - 可追溯 -
不破坏原始结果 - 路径稳定 - 训练程序可直接读取

------------------------------------------------------------------------

## STEP 10 --- 全量训练数据读取验收

**状态：待执行**

对最终 Manifest 中所有 Pair 执行一次全量读取。

检查： - RGB 文件存在 - Temperature 文件存在 - Mask 文件存在 - RGB
可读取 - Thermal 可读取 - Mask 可读取 - RGB/Temperature/Mask
空间尺寸一致 - Temperature float32 - NaN = 0 - Inf = 0 - Mask
有有效区域 - split 合法 - Pair ID 唯一 - 无 Train/Val/Test 交叉 - group
不跨 split

预期： **所有错误项 = 0**

------------------------------------------------------------------------

## STEP 11 --- DataLoader / Batch 冒烟测试

**状态：待执行**

这是"数据已经能直接训练"的最后一道检查。

使用最终： - Manifest - Split - RGB - Temperature - Mask - crop/patch
规则

实际读取训练数据并组成至少一个 batch。

至少验证： - RGB tensor shape 正确 - Temperature tensor shape 正确 -
Mask tensor shape 正确 - dtype 正确 - RGB/Temperature/Mask 同步裁剪 - 无
NaN / Inf - batch 可正常送入后续训练流程 - masked loss
所需数据格式已经具备

若 baseline 模型代码届时已确定，可进一步执行： - 1 个 batch forward - 1
次 loss 计算 - 1 次 backward

若模型尚未进入本任务范围，则至少完成 Dataset/DataLoader 层的 batch
冒烟测试；模型 forward/backward 归入下一阶段 baseline 任务。

------------------------------------------------------------------------

# 4. 最终必须生成并保存的成果

本次数据任务结束时，至少保留：

1.  **813 Pair 或最终确认后的有效 Pair**
2.  `004_pair_mapping.csv`
3.  Stage2↔Stage3 温度检查 CSV
4.  SDK v1.4↔v1.8 对照结果
5.  重复/连续帧检查结果
6.  RGB↔Thermal 视觉 QC 图
7.  Valid Mask
8.  `cynthia_final_manifest.csv`
9.  `train.csv`
10. `val.csv`
11. `test.csv`
12. 数据处理/训练输入规则 README
13. 最终数据验收 MD
14. 关键配置、SDK版本与温度提取参数记录

------------------------------------------------------------------------

# 5. 最终验收表模板

  项目                        最终结果           状态
  --------------------------- ------------------ -----------------
  004 配对修复                已修复，570 Pair   PASS
  三子集结构健康              当前 813 Pair      PASS
  shape/dtype                 0 错误             PASS
  NaN/Inf                     0                  PASS
  极端低温/warp 边缘          已检查             PASS
  Stage2↔Stage3 温度保持性    待填               TODO
  006 SDK v1.4↔v1.8           待填               TODO
  重复/连续序列               待填               TODO
  RGB↔Temperature 视觉配准    待填               TODO
  Valid Mask                  待生成             TODO
  Final Manifest              待生成             TODO
  Train/Val/Test 无泄漏划分   待完成             TODO
  输入尺寸/Patch策略          待确定             TODO
  全量读取检查                待执行             TODO
  DataLoader/Batch 冒烟测试   待执行             TODO
  **最终状态**                **尚未封版**       **IN PROGRESS**

------------------------------------------------------------------------

# 6. 本任务的真正结束标准

只有当以下全部满足时，本任务才结束：

-   [ ] 最终 Pair 数确定
-   [ ] Stage2↔Stage3 温度保持性通过
-   [ ] SDK 版本一致性问题关闭
-   [ ] 重复/连续帧问题关闭
-   [ ] RGB↔Temperature 视觉配准通过
-   [ ] Valid Mask 生成并验收
-   [ ] Final Manifest 完成
-   [ ] Train/Val/Test 按 group 划分完成
-   [ ] 输入尺寸/Patch策略确定
-   [ ] 最终数据目录/索引建立
-   [ ] 全量数据读取 0 错误
-   [ ] DataLoader/Batch 冒烟测试通过
-   [ ] 最终验收 MD 更新为完整结果版

最终状态必须写为：

> **DATA READY --- Cynthia 数据已完整处理并验收，可直接进入 baseline
> 模型训练。**

------------------------------------------------------------------------

# 7. 当前进度（2026-09-18）

当前已完成： - 004 配对问题定位与修复 - 004 Stage3 重新生成并通过 -
006/005/004 合并结构健康检查 - 最终候选 Pair = 813 - shape/dtype/NaN/Inf
检查 - Stage3 有效区域检查 - 极端低温/warp 边缘检查

当前下一批任务： 1. Stage2↔Stage3 温度保持性 2. 006 SDK v1.4↔v1.8 3.
重复/连续序列 4. RGB↔Temperature 视觉 QC 5. Mask 6. Manifest 7. Group
Split 8. 输入尺寸/Patch策略 9. 全量读取 10. DataLoader/Batch 冒烟测试
11. 最终封版

**本 MD 从现在开始作为 Cynthia 数据任务的总进度文件，持续更新到 DATA
READY，不在"数据验收"中途结束。**
